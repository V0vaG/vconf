# example-apt-repo

This example shows how to generate a debian (.deb) package, and create a signed apt-repo.

Run `earthly -P +test` to run the complete example, or run `earthly +create-repo` to
output the signed repo to the local directory.
